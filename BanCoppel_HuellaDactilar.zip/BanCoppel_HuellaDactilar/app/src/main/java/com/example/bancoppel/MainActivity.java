package com.example.bancoppel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.Executor;

@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private ImageView imageView;
    private FingerprintManager fingerprintManager;
    private FingerprintManager.AuthenticationCallback authenticationCallback;
    private CancellationSignal cancellationSignal;

    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;
    private Executor executor;

    private LinearLayout btnHuella;
    private LinearLayout btnRostro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textViewStatus);
        imageView = findViewById(R.id.imageViewStatus);
        btnHuella = findViewById(R.id.btnHuella);
        btnRostro = findViewById(R.id.btnRostro);

        setupFingerprintManager();

        setupBiometricPrompt();

        if (btnHuella != null) {
            btnHuella.setOnClickListener(this::scanButton);
        }

        if (btnRostro != null) {
            btnRostro.setOnClickListener(this::scanButton);
        }
    }

    private void setupFingerprintManager() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);

            authenticationCallback = new FingerprintManager.AuthenticationCallback() {
                @Override
                public void onAuthenticationError(int errorCode, CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    handleAuthError(errString != null ? errString.toString() : "Error en el sensor");
                }

                @Override
                public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
                    super.onAuthenticationHelp(helpCode, helpString);
                    handleAuthHelp(helpString != null ? helpString.toString() : "Ajusta la posición del dedo");
                }

                @Override
                public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    handleAuthSuccess();
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    handleAuthFailed();
                }
            };
        }
    }

    private void setupBiometricPrompt() {
        executor = ContextCompat.getMainExecutor(this);

        biometricPrompt = new BiometricPrompt(MainActivity.this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        handleAuthError(errString.toString());
                    }

                    @Override
                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        handleAuthSuccess();
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        super.onAuthenticationFailed();
                        handleAuthFailed();
                    }
                });

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("BanCoppel Móvil")
                .setSubtitle("Autenticación biométrica")
                .setDescription("Toca el sensor de huella dactilar para acceder a tu cuenta.")
                .setNegativeButtonText("Cancelar")
                .build();
    }

    public void scanButton(View view) {
        if (textView != null) {
            textView.setText("Esperando lectura del sensor biométrico...");
        }
        if (imageView != null) {
            imageView.setImageResource(R.drawable.cargando);
        }

        BiometricManager biometricManager = BiometricManager.from(this);
        int canAuth = biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);

        if (canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
            biometricPrompt.authenticate(promptInfo);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && fingerprintManager != null) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT)
                    == PackageManager.PERMISSION_GRANTED) {

                if (!fingerprintManager.isHardwareDetected()) {
                    Toast.makeText(this, "El dispositivo no cuenta con sensor de huella físico", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!fingerprintManager.hasEnrolledFingerprints()) {
                    Toast.makeText(this, "No hay huellas registradas en los ajustes del teléfono", Toast.LENGTH_LONG).show();
                    return;
                }

                if (cancellationSignal != null) {
                    cancellationSignal.cancel();
                }
                cancellationSignal = new CancellationSignal();

                fingerprintManager.authenticate(null, cancellationSignal, 0, authenticationCallback, null);
                Toast.makeText(this, "Sensor activo: Coloca tu huella", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        Toast.makeText(this, "Autenticación simulada: Exitosa", Toast.LENGTH_SHORT).show();
        handleAuthSuccess();
    }

    private void handleAuthSuccess() {
        if (textView != null) {
            textView.setText("¡Escaneo de huella dactilar exitoso!\nIniciando sesión…");
        }
        if (imageView != null) {
            imageView.setImageResource(R.drawable.correct);
        }
        Toast.makeText(MainActivity.this, "Autenticación exitosa", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
        startActivity(intent);
    }

    private void handleAuthFailed() {
        if (textView != null) {
            textView.setText("Escaneo fallido, huella dactilar no registrada");
        }
        if (imageView != null) {
            imageView.setImageResource(R.drawable.failed);
        }
        Toast.makeText(this, "Huella no reconocida", Toast.LENGTH_SHORT).show();
    }

    private void handleAuthError(String errString) {
        if (textView != null) {
            textView.setText("ERROR: " + errString);
        }
        if (imageView != null) {
            imageView.setImageResource(R.drawable.failed);
        }
    }

    private void handleAuthHelp(String helpString) {
        if (textView != null) {
            textView.setText("AYUDA: " + helpString);
        }
        if (imageView != null) {
            imageView.setImageResource(R.drawable.cargando);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (cancellationSignal != null) {
            cancellationSignal.cancel();
        }
    }
}