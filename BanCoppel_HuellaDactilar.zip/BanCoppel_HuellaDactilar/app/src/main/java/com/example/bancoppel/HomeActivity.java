package com.example.bancoppel;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class HomeActivity extends AppCompatActivity {

    private ImageButton btnCerrarSesion;
    private View navPerfilCerrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
        if (btnCerrarSesion != null) {
            btnCerrarSesion.setOnClickListener(this::acceptButton);
        }

        navPerfilCerrar = findViewById(R.id.navPerfilCerrar);
        if (navPerfilCerrar != null) {
            navPerfilCerrar.setOnClickListener(this::acceptButton);
        }
    }


    public void acceptButton(View view) {
        Intent intent = new Intent(HomeActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}